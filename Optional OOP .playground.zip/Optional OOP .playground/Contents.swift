import UIKit

//Tanımalama
var mesaj = "Merhaba"

//nil ? isareti koyarız nil diger dillerde null diye gecer.
var str:String? = nil

if str != nil {
    print(str!)//unwrap
}else{
    print("str nil değer içeriyor")
}


//optioanl binding
if var temp = str {
    print(temp)//otamatik unwrap
}else{
    print("str nil değer içeriyor")
}






