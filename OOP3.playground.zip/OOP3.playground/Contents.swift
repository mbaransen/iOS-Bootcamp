import UIKit


//Kalıtım

class Ev {
    var PencereSayisi:Int?
    
    init(PencereSayisi: Int) {
        self.PencereSayisi = PencereSayisi
    }
}

class Saray:Ev {
    var KuleSayisi:Int?
    
    init(KuleSayisi: Int, PencereSayisi:Int) {//kullanıcıdan deger almak icin boyle yapmalıyız.
        self.KuleSayisi = KuleSayisi
        super.init(PencereSayisi: PencereSayisi)//kalıtımda super methodunu kullanmalıyız yoksa hata verir.
    }
    
}

class Villa:Ev {
    var GarajVarMi:Bool?
    
    init(GarajVarMi: Bool, PencereSayisi:Int) {
        self.GarajVarMi = GarajVarMi
        super.init(PencereSayisi: PencereSayisi)
    }
}

let topkapiSarayi = Saray(KuleSayisi: 5, PencereSayisi: 300)
let bogazVilla = Villa(GarajVarMi: true, PencereSayisi: 30)

print(topkapiSarayi.KuleSayisi!)
print(topkapiSarayi.PencereSayisi!)

print(bogazVilla.GarajVarMi!)
print(bogazVilla.PencereSayisi!)


//Metodları Ezme: Overriding, ovveriding yapılması icin mutlaka kalıtım olması gerek.ÖNEMLİ

class Hayvan {
    func sesCikar(){
        print("Sesim yok")
    }
}

class Memeli: Hayvan {
    
    
}

class Kedi: Memeli {
    override func sesCikar() {//kalıtım yaptıgım icin sesCikar yazdıgım anda func gelir.
        print("Miyav Miyav")
    }
    
}

class Kopek: Memeli {
    override func sesCikar() {//kalıtım yaptıgım icin sesCikar yazdıgım anda func gelir.
        print("Hav Hav")
    }
    
}

let hayvan = Hayvan()
let memeli = Memeli()
let kedi = Kedi()
let kopek = Kopek()

hayvan.sesCikar()//Kalıtım yok, kendi fonksiyonunu çalıştırdı.
memeli.sesCikar()//Kalıtım var, üst sınıfın fonksiyonunu çalıştırdı.
kedi.sesCikar()//Kalıtım var, kendi metodunu çalıştırdı.
kopek.sesCikar()//kalıtım yaptıgım icin sesCikar yazdıgım anda func gelir.

//Downcasting - Upcasting  Tür Dönüşümü

//Upcasting alt class üst class a dönüşecek. Sadece as varsa upcasting as? veya as! varsa bu downcasting demektir.
var ev = Saray(KuleSayisi: 3, PencereSayisi: 10) as Ev

//Downcasting
var saray = Ev(PencereSayisi: 6) as! Saray

//Tip kontolü
if ev is Ev {
    print("Nesne ev sınıfındandır.")
}else{
    print("Nesne ev sınıfından değildir.")
}


//Protocol

protocol MyProtocol { //class a birden çok protocol eklenebilir.
    var degisken:Int {get set}
    
    func metod1()
    func metod2() -> String
}

class ClassA : MyProtocol {
    var degisken: Int = 10
    
    func metod1() {
        print("Metod 1 çalıştı")
    }
    
    func metod2() -> String {
        return "Metod 2 çalıştı"
    }
}

var a = ClassA()
print(a.degisken)
a.metod1()
print(a.metod2())


//Extension (Genişletme) sınıfa fonksiyon eklememizi saglar.Asagıda Int sınıfına carp func ekledik.

extension Int {
    func carp(sayi:Int) -> Int {//illa return olmak zorunda degil void de olabilir.
        return self * sayi
    }
}

let x = 3.carp(sayi: 5)
print(x)



//Closure 

let ifade = {
    print("Merhaba")
}

ifade()
