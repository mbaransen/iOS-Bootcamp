import UIKit

//Array Kullanımı.Köşeli parantez ile kullanılır.

var numaralar = [10,20,30]//Bu aşamada eleman verdik.
var meyveler = [String]()//Burada eleman vermedik eleman sonra verebiliriz genellikle bu sekilde kullanılır.

//Veri ekleme
meyveler.append("Elma")//0.index yerlesir.
meyveler.append("Muz")//1. index yerlesir.
meyveler.append("Kiraz")//2.index yerlesir.
print(meyveler)

//Güncelleme yapmak
meyveler[0] = "Yeni Elma"//0.index "Elma" idi "Yeni Elma" olmuş oldu

//Insert
meyveler.insert("Portakal", at: 1)//1.indexe portakalı yerlestir demektir.

//Veri okuma
print(meyveler[2])//2.indexi yazdır demek

let m = meyveler[0]
print(m)//0.indexi m ye aktarmış olduk.

print("Boyut : \(meyveler.count)")//eleman sayısı ögrenme
print("Boş kontorl : \(meyveler.isEmpty)")//boş mu dolu mu kontrol ettik


for meyve in meyveler {
    print("Sonuç 1 :\(meyve)")
}

meyveler.remove(at: 1)//1.indexi sil demektir.
print(meyveler)

//Nesne Tabanlı Örnek Yapma

class Ogrenciler {
    var no:Int?
    var ad:String?
    var sinif:String?
    
    init(no: Int?, ad: String?, sinif: String?) {
        self.no = no
        self.ad = ad
        self.sinif = sinif
    }
}
//Bu classdan nesne olusturalım.
var o1 = Ogrenciler(no: 200, ad: "Muzaffer", sinif: "9C")
var o2 = Ogrenciler(no: 300, ad: "Musa", sinif: "11Z")
var o3 = Ogrenciler(no: 100, ad: "Ahmet", sinif: "11A")

var ogrecilerListesi = [Ogrenciler]()
ogrecilerListesi.append(o1)
ogrecilerListesi.append(o2)
ogrecilerListesi.append(o3)

for o in ogrecilerListesi {
    print("No : \(o.no!) - Ad : \(o.ad!) - Sınıf : \(o.sinif!)")
}

//Filtreleme elinizde bir arry varsa belirli kosullara göre istedigin kadar veri alabilirsin.
var f1 = ogrecilerListesi.filter({ $0.no! > 100 })//numarası 100 den buyuk olanları yazdır demek istersen birden fazla kosul girebilirisin.
print("Filtreleme 1")
for o in f1 {
    print("No : \(o.no!) - Ad : \(o.ad!) - Sınıf : \(o.sinif!)")
}

//Sıralama - Sorting //verilerini istedigin degere göre sırlarsın mesela fiyatı azalandan artana dogru.COK ONEMLI
var s1 = ogrecilerListesi.sorted(by: {$0.no! > $1.no!})//no lar arasında bir kıyaslama yap demektir.0 veya 1 yazmak onemli değil.
print("Sayısal büyükten küçüğe")
for o in s1 {
    print("No : \(o.no!) - Ad : \(o.ad!) - Sınıf : \(o.sinif!)")
}








