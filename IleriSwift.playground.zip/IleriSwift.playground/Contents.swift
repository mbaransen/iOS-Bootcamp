import UIKit

func kisiTanima1(ad:String){
    if ad == "Ahmet" {
        print("Merhaba Ahmet")
    }else{
        print("Tanınmayan Kişi")
    }
}

kisiTanima1(ad: "Ahmetx")

//Guard, guard sadece else ile yazılır false gelen durumlar ıcın guard calısır gibi dusunebilrisin.

func kisiTanima2(ad:String){
    guard ad == "Ahmet" else {//sadece false oldugunda calısan bir yapı gibi düsünebilirisin.
        print("Tanınmayan kişi")
        return //return ile durdurmamız gerek
        
    }
}


//Hata Ayıklama
//1.Compile Error: Editör'ün bize verdgi hatalar.
//2.Runtime Error : (Exception) : Çalısma sırasında olusan hatalar.Yani kod da hata vermiyor ama uygulmayı calıstırdıgımızda uygulama cokuyor.

enum Hatalar : Error {
    case sifiraBolunmeHatasi
}

func bolme(sayi1:Int, sayi2:Int) throws -> Int {//throws koydugumuzda bir hata cıkabilir o yuzden enum da verdigim hatayı yazdır demektir.Boyle durumlarda Do-Try-Catch kullanırız.
    if sayi2 == 0 {
        throw Hatalar.sifiraBolunmeHatasi
    }
    return sayi1 / sayi2
}
do{
let sonuc = try bolme(sayi1: 10, sayi2: 2)
print(sonuc)

}catch Hatalar.sifiraBolunmeHatasi {
    print("Sayı sıfıra bölünmez")
}
