import UIKit

var ogrenciAdi = "Muzaffer Baran"
var ogrenciYas = 18
var ogrenciBoy = 1.85
var ogrenciBasharf = "M"
var ogrenciDevamEdiyormu = true

print(ogrenciAdi)
print(ogrenciYas)
print(ogrenciBoy)
print(ogrenciBasharf)
print(ogrenciDevamEdiyormu)

print("Ögrenci Ad : \(ogrenciAdi)") //Detaylı bir çıktı almak icin.

//Constant - Sabitler
//Swift - let

var sayi = 10
print(sayi)
sayi = 20
print(sayi)

//var dedigin degeri degistirebilirsin ama let dedigini degistiremessin.

let numara = 100
print(numara)//numara artık 100 dür asagıdaki satırlarda degistiremessin var gibi.


//Tür Dönüşümü - Type Casting
//Sayısaldan sayısala

var i = 42
var d = 56.78

var sonuc1 = Double(i)//Bu satır tam sayım(42) var bunu double'a dönüştürecegim  demektir.
var sonuc2 = Int(d)
print(sonuc1)
print(sonuc2)

//Sayısaldan Metine

var sonuc3 = String(i)
var sonuc4 = String(d)
print(sonuc3)
print(sonuc4)//çıktı olarak bir degisilik olmaz ama arka planda "42" ve "56.78" olarak algılar cunku stringe donusturduk.

//Metinden sayısala(Genellikle if let ile beraber kullanılır var ile değil.Ama var ile de kullanabilirsin.
var yazi = "34"

if let sonuc5 = Int(yazi) {
    print(sonuc5)
}



