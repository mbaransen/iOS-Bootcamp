import UIKit
//class isimleri büyük harfle başlat

class Araba {
    var renk:String?//bu degerleri kullancıdan alacagım icin mutlaka türünü belirtip ? koymmam gerek.
    var hiz:Int?
    var calisiyorMu:Bool?
    
    func calistir(){//side effect: bir fonksiyonla classın nesnelerinin içeriğini değiştirebiliyorsan buna side effect denir.ÖNEMLİ
        calisiyorMu = true
        hiz = 5
    }
    
    func durdur(){
        calisiyorMu = false
        hiz = 0
    }
    
    func hizlan(kacKm:Int){
        hiz!+=kacKm
        
    }
    
    func yavasla(kacKm:Int){
        hiz!-=kacKm
    }
    
    func bilgiAl(){
        
        print("----------------------")
        print("Renk         : \(renk!)")
        print("Hız          : \(hiz!)")
        print("Çalışıyor mu : \(calisiyorMu!)")

    }
}

//Nesne Olusturma
var bmw = Araba()//araba class ından nesne olusturdum.

//Değer atama
bmw.renk = "Gri"
bmw.hiz = 100
bmw.calisiyorMu = true

//Değer okuma
bmw.bilgiAl()//diyerek bütün değerleri çıktı alabilirim.
bmw.durdur()
bmw.bilgiAl()//durdur fonk. calıstırdıktan sonra bir daha bilgiAl calıstırmalısınki cıktı alsın.
bmw.calistir()
bmw.bilgiAl()
bmw.hizlan(kacKm: 50)//mevcut hızı zaten 5 di 50 ekledik 55 oldu.Mutlaka her adımdan sonra cıktı almak icin bilgiAl fonk. calıstırmalıyız.
bmw.bilgiAl()








