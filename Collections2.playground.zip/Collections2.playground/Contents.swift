import UIKit

//Set
var meyveler = Set<String>()

//Veri ekleme.Set de veri ekleme append ile değil insert ile olur ve set sırayla oluşturmaz.
meyveler.insert("Elma")
meyveler.insert("Portakal")
meyveler.insert("Muz")
print(meyveler)

meyveler.insert("Kırmızı Elma")
print(meyveler)

for meyve in meyveler {
    print("Sonuç : \(meyve)")
}

print("Boyut : \(meyveler.count)")
print("Boş mu : \(meyveler.isEmpty)")

meyveler.remove("Elma")//"Elma" verisini sil demektir.


//Dictionary - HashMap - Map
var iller = [Int:String]()//Bu sekilde olusturulur.

//Veri ekleme
iller[06] = "Ankara"
iller[34] = "İstanbul"

//Veri okuma
print(iller[06]!)

//Veri güncelleme
iller[06] = "Yeni Ankara"
print(iller)

for (anahtar,deger) in iller {
    print("\(anahtar) -> \(deger)")
}

//Veri silme.
iller.removeValue(forKey: 34)
print(iller)
