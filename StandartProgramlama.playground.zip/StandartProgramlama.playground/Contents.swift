import UIKit

//Karsılastırma Operatoru
var a = 40
var b = 50

var x = 90
var y = 80

print("a == b : \(a == b)")
print("a != b : \(a != b)")
print("a > b  : \(a > b)")
print("a >= b : \(a >= b)")
print("a < b  : \(a < b)")
print("a <= b : \(a <= b)")

print("a > b || x > y : \(a > b || x > y)")// || veya demektir.
print("a > b && x > y : \(a > b && x > y)")// && ve denektir.
