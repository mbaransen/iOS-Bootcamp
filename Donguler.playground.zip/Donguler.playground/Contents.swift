import UIKit

//if

var yas = 19
var isim = "Muzaffer"

// if den sonra direkt kosulu yaz parantez koyamana gerek yok
if yas >= 18 {
    print("Reşitsiniz")
}else{
    print("Reşit değilsiniz")//else diğer durumlar haricinde yapılacak seyleri yazdırır.
}

if isim == "Muzaffer" {
    print("Merhaba Muzaffer")
}else if isim == "Mehmet "{//else if diğer baska bir durumu kontrol etmek icin kullanılır yani if olmassa else if kontrol et oda olmasa else fonk. yazdır demektir.
    print("Merhaba Mehmet")
}else {
    print("Tanınmayan Kişi")
}

//Çoklu Koşul

var ba = "admin"
var s = 123456

if ba == "admin" && s == 123456 {//hem sol hem sağ taraf fogru olmalı.Ve(&&) yerine veya(||) da koyabilirisn.
    print("Hoşgeldiniz")
}else{
    print("Hatalı Giriş")
}

//Switch
//if gibi değidlir hemen sonra kosul yazılmaz.Kıyaslayacagımdır.
var gun = 3

switch gun {
case 1 : print("Pazartesi")
case 2 : print("Salı")
case 3 : print("Çarşamba")
case 4 : print("Perşembe")
case 5 : print("Cuma")
case 6 : print("Cumartesi")
case 7 : print("Pazar")
default: print("Böyle bir gün yok")//hicbir deger calısmassa default calısır.En son secenek
    
}

//Döngüler (for in, while)
//1,2,3 degerlerini görecegim döngü oluşturayım

for x in 1...3 {
    print("Döngü 1 : \(x)")
}


//10 ile 20 arasında 5 er artış olsun.
for a in stride(from: 10, through: 20, by: 5) {//bu tarz ozel durumlarda stride yapısı kullanılır.Azalmasını istersen by: - koymalısın.by: ne kadar artacağını azalacağını belirler.
    print("Döngü 2 : \(a)")
}

//ornek

var sayac = 1

while sayac < 4 {
    print("Döngü 4 : \(sayac)")
    sayac+=1// 1 artırarak git 4 den kucuk olunca durdur demektir.
}

//Dögüleri durdurmak ve bazı adımları atlamak

for i in 1...5 {
    if i == 3 {
        break
    }
    print("Döngü 5: \(i)")
}

for i in 1...5 {
    if i == 3 {
        continue
    }
    print("Döngü 6 : \(i)")
}

    
